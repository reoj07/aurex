<?php
session_start();

$error = '';
$login_type = $_POST['login_type'] ?? 'mobile';

if (isset($_POST['login'])) {

    $identifier = trim($_POST['identifier'] ?? '');
    $password   = trim($_POST['password'] ?? '');
    $login_type = $_POST['login_type'] ?? 'mobile';

    if ($identifier == '' || $password == '') {
        $error = 'Please enter your login details.';
    } else {

        if ($login_type == 'email') {
            // EMAIL LOGIN
            // Example:
            // SELECT * FROM users WHERE email='$identifier'
        } else {
            // MOBILE LOGIN
            // Example:
            // SELECT * FROM users WHERE mobile='$identifier'
        }

        // TODO:
        // Verify password
        // Redirect if success
        // header("Location: home.php");
        // exit;
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
      name="description"
      content="Mobile-first crypto exchange web application with centralized market and chart configuration."
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Sora:wght@600;700&display=swap"
      rel="stylesheet"
    />
    <title>AURX Exchange Login</title>
    <link rel="stylesheet" href="./client/assets/common.css" />
    <link rel="stylesheet" href="./client/assets/pages/login.css" />
    <script defer src="./client/assets/common.js"></script>
    <script defer src="./client/assets/pages/login.js"></script>
  </head>
  <body data-static-route="/login" data-page="login">
    <div id="root">
      <div class="app-shell">
        <div class="screen no-bottom-nav login-screen">
          <div class="login-layout">
            <header class="login-top-row">
              <button type="button" class="login-back-button" aria-label="Back">
                <svg
                  viewBox="0 0 24 24"
                  class="ui-icon icon-back"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="1.8"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  aria-hidden="true"
                >
                  <path d="M15 6l-6 6 6 6"></path>
                </svg></button
              ><button type="button" class="login-language-button">
                English
              </button>
            </header>
            <section class="login-hero-block"><h1>Login</h1></section>
            <div
              class="login-mode-tabs"
              role="tablist"
              aria-label="Login method"
            >
              <button
                type="button"
                role="tab"
                class="login-mode-tab active"
                aria-selected="true"
              >
                Email</button
              ><button
                type="button"
                role="tab"
                class="login-mode-tab"
                aria-selected="false"
              >
                Mobile number
              </button>
            </div>
            <form class="login-form">
              <label class="login-field"
                ><input
                  inputmode="email"
                  placeholder="Please enter your email address"
                  aria-label="Email"
                  type="email"
                  value="" /></label
              ><label class="login-field"
                ><input
                  placeholder="Please enter your password"
                  aria-label="Password"
                  type="password"
                  value="" /></label
              ><label class="login-remember-row"
                ><input type="checkbox" checked="" /><span
                  >Remember my password</span
                ></label
              ><button type="submit" class="login-primary-action">Login</button>
            </form>
            <button type="button" class="login-secondary-action">
              Download APP
            </button>
            <div class="login-link-row">
              <a
                class="login-inline-link"
                href="./register.html"
                data-discover="true"
                >Register</a
              ><a
                class="login-inline-link"
                href="./support.html"
                data-discover="true"
                >Forget password?</a
              >
            </div>
            <a
              class="login-support-link"
              href="./support.html"
              data-discover="true"
              ><span class="login-support-icon" aria-hidden="true"
                ><svg
                  viewBox="0 0 24 24"
                  class="ui-icon icon-menu-support"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="1.8"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  aria-hidden="true"
                >
                  <path
                    d="M12 18v.01M8.5 9.5a3.5 3.5 0 117 0c0 2-1.7 2.7-2.6 3.4-.6.4-.9.8-.9 1.6M4 12a8 8 0 1016 0 8 8 0 10-16 0z"
                  ></path></svg></span
              ><span>Contact Customer Service</span></a
            >
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
